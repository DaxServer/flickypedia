from .cli import extractr as extractr_cli

__all__ = ["extractr_cli"]
