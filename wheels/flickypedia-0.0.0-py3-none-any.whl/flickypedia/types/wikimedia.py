import typing


class ShortCaption(typing.TypedDict):
    language: str
    text: str
