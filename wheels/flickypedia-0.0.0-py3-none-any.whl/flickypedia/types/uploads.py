import typing

from flickr_photos_api import SinglePhoto

from flickypedia.structured_data import NewClaims
from flickypedia.types.wikimedia import ShortCaption


# Types for upload requests.


class UploadRequest(typing.TypedDict):
    photo: dict
    sdc: NewClaims|None
    title: str|None
    caption: ShortCaption|None
    categories: list[str]|None
    username: str
    license: str|None


class KeyringId(typing.TypedDict):
    service_name: str
    username: str


class UploadBatch(typing.TypedDict):
    keyring_id: KeyringId
    requests: list[UploadRequest]


# Types for upload results.


class SuccessfulUpload(typing.TypedDict):
    id: str
    title: str
    state: typing.Literal["succeeded"]


class FailedUpload(typing.TypedDict):
    state: typing.Literal["failed"]
    error: str


class PendingUpload(typing.TypedDict):
    state: typing.Literal["waiting", "in_progress"]


IndividualUploadResult = SuccessfulUpload | FailedUpload | PendingUpload

UploadBatchResults = dict[str, IndividualUploadResult]
