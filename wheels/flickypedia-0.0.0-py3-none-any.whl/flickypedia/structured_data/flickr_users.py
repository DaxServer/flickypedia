class FlickrUsers:
    """
    Named constants for the NSID of certain Flickr users.
    """

    # https://www.flickr.com/photos/biodivlibrary/
    BioDivLibrary = "61021753@N02"
