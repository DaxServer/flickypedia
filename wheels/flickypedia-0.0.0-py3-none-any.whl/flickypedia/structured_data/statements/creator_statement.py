from flickr_photos_api import User as FlickrUser

from ..types import NewStatement, QualifierValues, create_qualifiers
from ..wikidata_properties import WikidataProperties


def create_flickr_creator_statement(user: FlickrUser) -> NewStatement:
    """
    Create a structured data statement for a user on Flickr.

    This is either:

    *   A link to the corresponding Wikidata entity, or
    *   A collection of values that link to their profile page

    """
    qualifier_values: list[QualifierValues] = [
        {
            "property": WikidataProperties.AuthorName,
            "value": (user["realname"] or user["username"]).strip(),
            "type": "string",
        },
        {
            "property": WikidataProperties.Url,
            "value": user["profile_url"],
            "type": "string",
        },
        {
            "property": WikidataProperties.FlickrUserId,
            "value": user["id"],
            "type": "string",
        },
    ]

    return {
        "mainsnak": {
            "snaktype": "somevalue",
            "property": WikidataProperties.Creator,
        },
        "qualifiers": create_qualifiers(qualifier_values),
        "qualifiers-order": [
            WikidataProperties.FlickrUserId,
            WikidataProperties.AuthorName,
            WikidataProperties.Url,
        ],
        "type": "statement",
    }


def create_youtube_creator_statement(channel_id: str, channel_name: str|None, channel_handle: str|None) -> NewStatement:
    """
    Create a structured data statement for a user on YouTube.

    This is either:

    *   A link to the corresponding Wikidata entity, or
    *   A collection of values that link to their profile page

    """
    qualifier_values: list[QualifierValues] = []

    if channel_name:
        qualifier_values.append({
            "property": WikidataProperties.AuthorName,
            "value": channel_name,
            "type": "string",
        })

    if channel_handle:
        qualifier_values.append({
            "property": WikidataProperties.YouTubeHandle,
            "value": channel_handle,
            "type": "string",
        })

    qualifier_values.append({
        "property": WikidataProperties.YouTubeChannelId,
        "value": channel_id,
        "type": "string",
    })

    return {
        "mainsnak": {
            "snaktype": "somevalue",
            "property": WikidataProperties.Creator,
        },
        "qualifiers": create_qualifiers(qualifier_values),
        "qualifiers-order": [q["property"] for q in qualifier_values],
        "type": "statement",
    }
