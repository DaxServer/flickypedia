import functools

from flask import abort, jsonify, request
from flask_login import current_user, login_required
from flask_wtf.csrf import generate_csrf

from flickypedia.apis.wikimedia import top_n_languages, LanguageMatch, WikimediaApi
from flickypedia.types.views import ViewResponse


@login_required
def validate_title_api() -> ViewResponse:
    """
    A basic API for title validation that can be called from JS on the page.

    This allows us to have a single definition of title validation
    which is shared by client and server-side checks.
    """
    try:
        title = request.args["title"]
    except KeyError:
        abort(400)

    if not title.startswith("File:"):
        abort(400)

    api = current_user.wikimedia_api()
    result = api.validate_title(title)

    return jsonify(result)


def validate_titles_api() -> ViewResponse:
    """
    A basic API for multiple titles validation that can be called from JS on the page.
    """
    try:
        titles = request.json["titles"]
    except KeyError:
        abort(400)

    if not titles:
        abort(400)

    api = current_user.wikimedia_api()

    results = []
    for title in titles:
        results.append(api.validate_title(title))

    return jsonify(results)


@login_required
def validate_license_api() -> ViewResponse:
    """
    A basic API for license validation that can be called from JS on the page.
    """
    try:
        license = request.args["license"]
    except KeyError:
        abort(400)

    if not license.startswith("Template:"):
        abort(400)

    api = current_user.wikimedia_api()
    result = api.validate_license(license)

    return jsonify(result)


@functools.lru_cache(maxsize=128)
def find_matching_categories(query: str) -> list[dict[str, str]]:
    """
    Find matching categories.  Because this is a read-only query on the
    global Wikimedia namespace, we cache the results of this lookup across
    all Flickypedia users.
    """
    api = current_user.wikimedia_api()
    result = api.find_matching_categories(query)
    return result


@login_required
def find_matching_categories_api() -> ViewResponse:
    """
    A basic API for looking up matching categories that can be called
    from JS on the page.
    """
    query = request.args.get("query")

    if not query:
        abort(400)

    result = find_matching_categories(query)

    return jsonify(result)


@functools.lru_cache(maxsize=128)
def find_matching_templates(query: str) -> list[str]:
    """
    Find matching templates.  Because this is a read-only query on the
    global Wikimedia namespace, we cache the results of this lookup across
    all Flickypedia users.
    """
    api = current_user.wikimedia_api()
    result = api.find_matching_templates(query)
    return result


@login_required
def find_matching_templates_api() -> ViewResponse:
    """
    A basic API for looking up matching templates that can be called
    from JS on the page.
    """
    query = request.args.get("query")

    if not query:
        abort(400)

    result = []
    for template in find_matching_templates(query):
        result.append({"id": template, "label": template, "match_text": None})

    return jsonify(result)


@functools.lru_cache(maxsize=128)
def find_matching_languages(query: str) -> list[LanguageMatch]:
    """
    Find matching languages.  Because this is a read-only query on the
    global Wikimedia namespace, we cache the results of this lookup across
    all Flickypedia users.
    """
    api = current_user.wikimedia_api()
    result = api.find_matching_languages(query)
    return result


@login_required
def find_matching_languages_api() -> ViewResponse:
    """
    A basic API for looking up matching languages that can be called
    from JS on the page.
    """
    query = request.args.get("query")

    if not query:
        return jsonify(
            [
                {"id": lang_id, "label": label, "match_text": None}
                for lang_id, label in top_n_languages(n=10)
            ]
        )

    result = find_matching_languages(query)

    return jsonify(result)


@login_required
def get_csrf_token() -> ViewResponse:
    return jsonify({"csrf_token": generate_csrf()})


def whoami():
    if current_user.is_anonymous:
        can_override_license = False
        username = None
        id = None
    else:
        user_info = current_user.wikimedia_api().get_userinfo()
        can_override_license = "patroller" in user_info["groups"] or "sysop" in user_info["groups"]
        username = user_info["name"]
        id = user_info["id"]

    return jsonify({
        "id": id,
        "user": username,
        "is_anonymous": current_user.is_anonymous,
        "is_authenticated": current_user.is_authenticated,
        "can_override_license": can_override_license,
    })
